-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s10p22c108
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `missions`
--

DROP TABLE IF EXISTS `missions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `missions` (
  `mission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mission_content` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`mission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `missions`
--

LOCK TABLES `missions` WRITE;
/*!40000 ALTER TABLE `missions` DISABLE KEYS */;
INSERT INTO `missions` VALUES (1,'따뜻한 아침 인사를 보내세요'),(2,'좋아하는 음악 플레이리스트를 만들어 공유하세요'),(3,'응원의 글귀를 작성해 메시지로 보내세요'),(4,'최근 성취를 칭찬하는 메모를 남겨주세요'),(5,'건강을 위해 집에서 할 수 있는 간단한 운동 루틴을 제안하세요'),(6,'오늘 하루를 긍정적으로 시작할 수 있는 명언을 보내주세요'),(7,'직접 그린 그림을 선물하세요'),(8,'직접 작성한 손편지를 보내세요'),(9,'편안한 밤을 위한 ASMR 비디오나 음악을 추천해주세요'),(10,'취미나 관심사에 관련된 책을 추천해주세요'),(11,'새로운 취미 활동을 제안하세요'),(12,'작은 선물을 전달하세요'),(13,'이번 주 목표를 함께 세우고 응원하세요'),(14,'건강한 간식 레시피를 공유하세요'),(15,'자기 관리 팁을 공유하세요'),(16,'주변 자연을 즐길 수 있는 산책이나 하이킹 장소를 추천해주세요'),(17,'개인화된 모닝 루틴을 제안하세요'),(18,'영감을 주는 이야기나 책을 추천하세요'),(19,'향기로운 캔들이나 아로마테라피 제품을 선물하세요'),(20,'응원하고 지지하는 메시지를 보내세요'),(21,'좋아하는 캐릭터를 그려서 선물하세요'),(22,'본인이 좋아하는 음료를 가져다 주세요'),(23,'간단하게 먹을 수 있는 작은 간식을 선물하세요'),(24,'가방이나 책상에 몰래 응원문구를 담은 포스트잇을 붙여주세요'),(25,'노래를 추천해주세요'),(26,'재미있는 퀴즈를 보내주세요'),(27,'아재개그를 보내주세요'),(28,'웃긴 릴스나 쇼츠를 보내세요');
/*!40000 ALTER TABLE `missions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04  1:27:07
