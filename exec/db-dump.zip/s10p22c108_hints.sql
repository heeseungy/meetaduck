-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s10p22c108
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hints`
--

DROP TABLE IF EXISTS `hints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hints` (
  `hint_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hint_content` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`hint_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hints`
--

LOCK TABLES `hints` WRITE;
/*!40000 ALTER TABLE `hints` DISABLE KEYS */;
INSERT INTO `hints` VALUES (1,'별자리는 무엇인가요?'),(2,'가장 좋아하는 색깔은 무엇인가요?'),(3,'최근에 본 가장 인상 깊은 영화는 무엇인가요?'),(4,'좋아하는 음식과 싫어하는 음식은 무엇인가요?'),(5,'여행 가고 싶은 나라는 어디인가요?'),(6,'가장 좋아하는 계절은 무엇인가요?'),(7,'취미는 무엇인가요?'),(8,'읽고 있는 책이나 최근에 읽은 책은 무엇인가요?'),(9,'가장 좋아하는 음악 장르는 무엇인가요?'),(10,'가장 좋아하는 동물은 무엇인가요?'),(11,'즐겨 보는 유튜브 채널이 있다면?'),(12,'자신만의 스트레스 해소 방법은 무엇인가요?'),(13,'가장 좋아하는 운동은 무엇인가요?'),(14,'가장 최근에 감동받은 일은 무엇인가요?'),(15,'가장 기억에 남는 생일 선물은 무엇인가요?'),(16,'기억에 남는 여행지는 어딘가요?'),(17,'가장 좋아하는 TV 프로그램은 무엇인가요?'),(18,'어릴 적 꿈은 무엇이었나요?'),(19,'가장 기억에 남는 꿈은 무엇인가요?'),(20,'어떤 종류의 영화를 가장 좋아하나요?'),(21,'가장 좋아하는 음료는 무엇인가요?'),(22,'가장 좋아하는 과일은 무엇인가요?'),(23,'주말에 주로 무엇을 하나요?'),(24,'MBTI가 어떻게 되나요?'),(25,'강아지 vs 고양이?'),(26,'짜장면 vs 짬뽕?'),(27,'여름 vs 겨울?'),(28,'본인의 TMI는?'),(29,'산 vs 바다?'),(30,'본인을 한 단어로 표현하면?');
/*!40000 ALTER TABLE `hints` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04  1:27:08
