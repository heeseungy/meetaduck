-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: stg-yswa-kr-practice-db-master.mariadb.database.azure.com    Database: s10p22c108
-- ------------------------------------------------------
-- Server version	5.6.47.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `topics`
--

DROP TABLE IF EXISTS `topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `topics` (
  `topic_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `topic_content` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`topic_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topics`
--

LOCK TABLES `topics` WRITE;
/*!40000 ALTER TABLE `topics` DISABLE KEYS */;
INSERT INTO `topics` VALUES (1,'매일 새로운 헤어스타일로 깨어나기 VS 매일 새로운 옷차림으로 깨어나기'),(2,'영원히 여름 날씨 VS 영원히 겨울 날씨'),(3,'한 번의 손짓으로 청소가 끝나는 능력 VS 요리가 완성되는 능력'),(4,'물 속에서 숨쉴 수 있는 능력 VS 하늘을 날 수 있는 능력'),(5,'한 달 동안 인터넷 없이 생활하기 VS 한 달 동안 친구들과 만나지 않기'),(6,'매일 같은 옷만 입기 VS 매일 같은 음식만 먹기'),(7,'우주 여행 한 번 가기 VS 지구 상에서 어디든 평생 무료로 여행하기'),(8,'미래를 볼 수 있는 능력 VS 과거로 돌아갈 수 있는 능력'),(9,'평생 동안 슈퍼히어로 영화만 보기 VS 평생 동안 로맨틱 코미디 영화만 보기'),(10,'시간을 멈출 수 있는 능력 VS 마음을 읽을 수 있는 능력'),(11,'평생 동안 취미를 즐기며 살기 VS 꿈의 직업을 가지고 일하며 살기'),(12,'모든 게임에서 이기는 능력 VS 모든 시험에서 만점 받는 능력'),(13,'매일 웃긴 일만 일어나는 삶 VS 매일 신나는 모험이 있는 삶'),(14,'소설 속 세계로 들어갈 수 있는 능력 VS 영화 속 세계로 들어갈 수 있는 능력'),(15,'영원히 젊게 살기 VS 무한한 지혜 가지기'),(16,'과거 큰 실수 하나를 바로잡을 수 있는 기회 VS 미래의 큰 성공을 보장받는 기회'),(17,'책 속 모든 지혜를 내 것으로 만들기 VS 영화 속 모든 기술을 내 것으로 만들기'),(18,'항상 사람들을 웃게 만드는 유머 감각 가지기 VS 새로운 아이디어로 감탄을 자아내는 창의력 가지기'),(19,'한 달 동안 맨발로 다니기 VS 한 달 동안 장갑을 끼고 생활하기'),(20,'한식만 평생 먹기 VS 양식만 평생 먹기'),(21,'유명한 가수로 데뷔하기 VS 유명한 배우로 데뷔하기'),(22,'역사적 사건의 진실을 알 수 있는 능력 VS 미래의 사건을 미리 알 수 있는 능력'),(23,'어릴 적 기억만 생생하게 기억나기 VS 최근 일 년의 기억만 생생하게 기억나기'),(24,'세상에서 가장 빠르게 달릴 수 있는 능력 VS 세상에서 가장 높이 뛸 수 있는 능력'),(25,'모든 사람을 친구로 만들 수 있는 카리스마 VS 어떤 문제도 해결할 수 있는 지혜'),(26,'어떤 악기든 마스터할 수 있는 능력 VS 어떤 게임이든 고수가 될 수 있는 능력'),(27,'매일 다른 시간대에서 깨어나기 VS 매일 다른 연대에서 깨어나기'),(28,'마음대로 색상을 바꿀 수 있는 능력 VS 마음대로 물체의 모양을 바꿀 수 있는 능력'),(29,'초능력을 얻는 대신 매일 랜덤한 부작용을 겪기 VS 평범한 삶을 사는 대신 매일 행운을 얻기'),(30,'매일 새로운 악기 연주법을 배우기 VS 매일 새로운 언어를 배우기'),(31,'헤어질 수 없는 진정한 사랑을 찾기 VS 세계에서 가장 영향력 있는 인물이 되기');
/*!40000 ALTER TABLE `topics` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04  1:27:07
